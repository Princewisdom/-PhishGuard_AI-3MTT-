import pickle
from sklearn.feature_extraction.text import TfidfVectorizer
import numpy as np

# Load model and vectorizer
with open("phishing_model.pkl", "rb") as f:
    phishing_model = pickle.load(f)

with open("vectorizer.pkl", "rb") as f:
    vectorizer = pickle.load(f)

# Function to predict message
def predict_message(message):
    vect_msg = vectorizer.transform([message])
    prediction = phishing_model.predict(vect_msg)[0]
    print(f"\n📬 Prediction: This message is likely **{prediction.upper()}**")

    if prediction == "phishing":
        show_suspicious_keywords(phishing_model, vectorizer)

# Function to show top phishing keywords
def show_suspicious_keywords(phishing_model, vectorizer, top_n=10):
    try:
        feature_names = vectorizer.get_feature_names_out()
        class_labels = phishing_model.classes_

        phishing_index = list(class_labels).index("phishing")
        feature_log_prob = phishing_model.feature_log_prob_[phishing_index]

        top_indices = feature_log_prob.argsort()[-top_n:][::-1]
        print("\n🕵️ Suspicious keywords commonly found in phishing emails:")
        for i in top_indices:
            print(f" - {feature_names[i]}")
    except Exception as e:
        print("⚠️ Unable to display suspicious keywords:", e)

# === TEST HERE ===
if __name__ == "__main__":
    sample_message = input("\n✉️ Enter an email message:\n")
    predict_message(sample_message)
