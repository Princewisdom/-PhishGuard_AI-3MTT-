import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.naive_bayes import MultinomialNB
from sklearn.pipeline import make_pipeline
import joblib

# Load data
data = pd.read_csv("ai_model.csv")
X = data["message"]  # Your text column
y = data["label"]

# Create pipeline with vectorizer and classifier
pipeline = make_pipeline(TfidfVectorizer(), MultinomialNB())

# Train the pipeline
pipeline.fit(X, y)

# Save the complete pipeline (vectorizer + model)
joblib.dump(pipeline, "phishing_model.pkl")

print("✅ Model pipeline saved as phishing_model.pkl")
