import pandas as pd
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.naive_bayes import MultinomialNB
from sklearn.pipeline import make_pipeline
import joblib

# Load data
data = pd.read_csv("ai_model.csv")

# Build model pipeline
model = make_pipeline(CountVectorizer(), MultinomialNB())

# Train the model
model.fit(data['message'], data['label'])
# Save the trained model
joblib.dump(model, "phishing_model.pkl")
print("✅ Model trained and saved as 'phishing_model.pkl'")

# Predict function
def check_message(msg):
    prediction = model.predict([msg])
    print(f"\nMessage: {msg}")
    print(f"Prediction: {prediction[0].upper()}")

# Example
if __name__ == "__main__":
    user_input = input("Paste a suspicious message: ")
    check_message(user_input)
