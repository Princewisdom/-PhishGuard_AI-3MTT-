import tkinter as tk
from tkinter import messagebox
import joblib
from lime.lime_text import LimeTextExplainer
from openai import OpenAI
import os
import sys

# ─── Support for PyInstaller (.exe) ──────────────────────────
def resource_path(relative_path):
    """ Get absolute path to resource (for PyInstaller .exe support) """
    try:
        base_path = sys._MEIPASS  # PyInstaller extracts to temp folder
    except Exception:
        base_path = os.path.abspath(".")

    return os.path.join(base_path, relative_path)

# ─── Load the Trained Local Model ─────────────────────────────
model = joblib.load(resource_path("phishing_model.pkl"))

# ─── Initialize OpenAI API Client ─────────────────────────────
client = OpenAI(api_key="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")

# ─── Set Up LIME Text Explainer ──────────────────────────────
explainer = LimeTextExplainer(class_names=["Phishing", "Legit"])

# ─── Local Model Prediction Function ─────────────────────────
def predict_local_model(msg):
    prediction = model.predict([msg])[0]
    proba = model.predict_proba([msg])[0]
    result = (
        f"Prediction: {prediction.upper()}\n\n"
        f"Legit: {proba[1]*100:.2f}%  |  Phishing: {proba[0]*100:.2f}%"
    )
    messagebox.showinfo("Prediction Result", result)

# ─── OpenAI Model Prediction Function ────────────────────────
def predict_openai_model(msg):
    try:
        prompt = f"Classify this message as 'phishing' or 'safe':\n\n{msg}"
        response = client.chat.completions.create(
            model="gpt-3.5-turbo",
            message=[{"role": "user", "content": prompt}],
            temperature=0
        )
        prediction = response.choices[0].message.content.strip()
        messagebox.showinfo("OpenAI Prediction", f"Prediction: {prediction}")
    except Exception as e:
        messagebox.showerror("OpenAI Error", f"Failed to get response:\n{e}")

# ─── Decide Which Model to Use ───────────────────────────────
def predict_message(use_external=False):
    msg = input_text.get("1.0", tk.END).strip()
    if not msg:
        messagebox.showwarning("Input Error", "Please enter a message.")
        return
    if use_external:
        predict_openai_model(msg)
    else:
        predict_local_model(msg)

# ─── LIME Explanation Function ───────────────────────────────
def explain_prediction():
    msg = input_text.get("1.0", tk.END).strip()
    if not msg:
        messagebox.showwarning("Input Error", "Please enter a message first.")
        return

    def predictor(texts):
        return model.predict_proba(texts)

    explanation = explainer.explain_instance(msg, predictor, num_features=6)
    terms = explanation.as_list()

    text = "Why this prediction?\n\n"
    for word, weight in terms:
        pct = abs(weight) * 100
        if weight > 0:
            text += f"– “{word}” increased legitimacy likelihood by {pct:.1f}%\n"
        else:
            text += f"– “{word}” increased Phishing by {pct:.1f}%\n"

    messagebox.showinfo("Explanation", text)

# ─── GUI Layout & Widgets ─────────────────────────────────────
root = tk.Tk()
root.title("AI Phishing Detector")

tk.Label(root, text="Enter Suspicious Message:", font=("Arial", 12)).pack(pady=5)
input_text = tk.Text(root, height=12, width=60, font=("Arial", 10))
input_text.pack(pady=5)

tk.Button(
    root,
    text="Detect Phishing (Local)",
    command=lambda: predict_message(use_external=False),
    font=("Arial", 12, "bold"),
    bg="blue",
    fg="white"
).pack(pady=5)

tk.Button(
    root,
    text="Detect Phishing (ChatGPT)",
    command=lambda: predict_message(use_external=True),
    font=("Arial", 12, "bold"),
    bg="green",
    fg="white"
).pack(pady=5)

tk.Button(
    root,
    text="Explain Prediction",
    command=explain_prediction,
    font=("Arial", 12),
    bg="gray",
    fg="white"
).pack(pady=5)

root.mainloop()
